-- 2_1
SELECT
    MIN(grade)
FROM
    studentcourserelations
WHERE
    course_id = 1
    OR course_id = 3
    AND year >= 1399
    AND year <= 1500;

----------------------------------------------------------------
-- 2_2
SELECT DISTINCT
    grade
FROM
    studentcourserelations
WHERE
    grade IS NOT NULL
ORDER BY
    grade
LIMIT
    2;

----------------------------------------------------------------
-- 2_3
SELECT
    MIN(grade) as min_grade,
    course_id
FROM
    studentcourserelations
GROUP BY
    course_id
ORDER BY
    min_grade;

----------------------------------------------------------------
-- 2_4
SELECT
    student_id,
    SUM(grade) AS sum_grade
FROM
    studentcourserelations
GROUP BY
    (student_id)
HAVING
    COUNT(student_id) >= 2;

----------------------------------------------------------------
-- 2_5
SELECT
    MAX(grade),
    course_id
FROM
    studentcourserelations
GROUP BY
    (course_id)
HAVING
    COUNT(course_id) >= 1
    AND MIN(grade) > 5;

----------------------------------------------------------------
-- 2_6
SELECT
    student_id,
    course_id
FROM
    studentcourserelations
GROUP BY
    student_id,
    course_id
HAVING
    COUNT(course_id) = 2;

----------------------------------------------------------------
-- 2_7
SELECT
    course_id
FROM
    studentcourserelations
WHERE
    year IN (1400, 1401)
EXCEPT
SELECT
    course_id
FROM
    studentcourserelations
WHERE
    year IN (1402, 1403)
GROUP BY
    (course_id);
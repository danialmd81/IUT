-- 1_1
CREATE Table StudentCourseRelations (
    id INT,
    student_id INT,
    course_id INT,
    year INT,
    grade NUMERIC(3, 1),
    PRIMARY KEY (id),
    Foreign Key (student_id) REFERENCES Students (id),
    Foreign Key (course_id) REFERENCES Courses (id)
);

INSERT INTO
    StudentCourseRelations
VALUES
    (12, 4001234, 2, 1401, 20);

----------------------------------------------------------------------------
-- 1_2
CREATE Table StudentDetails (student_id INT, description NVARCHAR (40));

INSERT INTO
    StudentDetails
SELECT
    id,
    N'با تجربه'
FROM
    students
WHERE
    id < 3950000;

----------------------------------------------------------------------------
-- 1_3
UPDATE StudentCourseRelations
SET
    grade = (
        SELECT
            avg_grade
        FROM
            (
                SELECT
                    AVG(grade) AS avg_grade
                FROM
                    StudentCourseRelations
                WHERE
                    grade IS NOT NULL
            ) AS derived_table
    )
WHERE
    grade IS NULL;

----------------------------------------------------------------------------
-- 1_4
DELETE FROM StudentCourseRelations;

INSERT INTO
    StudentCourseRelations
VALUES
    (05, 4015555, 1, 1401, 11),
    (08, 4015555, 3, NULL, 18.5),
    (11, 4025678, 3, 1403, 20),
    (04, 4025678, 3, 1402, 19),
    (02, 3779898, 1, 1380, 13),
    (01, 4001234, 1, 1401, 18),
    (07, 4015555, 2, 1400, 16),
    (09, 4004321, 1, 1401, 15),
    (10, 4001234, 3, null, 17),
    (03, 4004321, 2, 1403, null);

UPDATE StudentCourseRelations
SET
    grade = (
        SELECT
            avg_grade
        FROM
            (
                SELECT
                    AVG(grade) AS avg_grade
                FROM
                    StudentCourseRelations
                WHERE
                    grade IS NOT NULL
                    AND course_id = StudentCourseRelations.course_id
            ) AS derived_table
    )
WHERE
    grade IS NULL;

----------------------------------------------------------------------------
-- 1_5
UPDATE StudentCourseRelations
SET
    grade = (
        CASE
            WHEN grade IS NULL THEN (
                SELECT
                    avg_grade
                FROM
                    (
                        SELECT
                            AVG(grade) AS avg_grade
                        FROM
                            StudentCourseRelations
                        WHERE
                            grade IS NOT NULL
                            AND course_id = StudentCourseRelations.course_id
                    ) AS derived_table
            )
            WHEN grade < 10 THEN 10
            WHEN course_id = 1 THEN grade * 1.1
            ELSE grade
        END
    )

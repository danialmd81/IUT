-- 3_1
SELECT
    res.student_id,
    COUNT(res.course_id)
FROM
    (
        SELECT
            *
        FROM
            studentcourserelations
    ) as res
WHERE
    grade > 14
GROUP BY
    (student_id);

------------------------------------------------------------------------
-- 3_2
SELECT
    res.student_id,
    COUNT(res.course_id)
FROM
    (
        SELECT
            *
        FROM
            studentcourserelations
    ) AS res
GROUP BY
    (student_id)
HAVING
    AVG(grade) > 14;

----------------------------------------------------------------------------
-- 3_3
SELECT
    student_id,
    COUNT(course_id),
    AVG(grade)
FROM
    studentcourserelations
GROUP BY
    (student_id)
HAVING
    AVG(grade) > (
        SELECT
            AVG(grade)
        FROM
            studentcourserelations
    );

-- 5_2
DELETE FROM StudentCourseRelations;

INSERT INTO
    StudentCourseRelations
VALUES
    (05, 4015555, 1, 1401, 11),
    (08, 4015555, 3, NULL, 18.5),
    (11, 4025678, 3, 1403, 20),
    (04, 4025678, 3, 1402, 19),
    (02, 3779898, 1, 1380, 13),
    (01, 4001234, 1, 1401, 18),
    (07, 4015555, 2, 1400, 16),
    (09, 4004321, 1, 1401, 15),
    (10, 4001234, 3, null, 17),
    (03, 4004321, 2, 1403, null);

SELECT
    name,
    family,
    isGraduated,
    major_name
FROM
    students AS stu
    INNER JOIN studentcourserelations AS stc ON stu.id = stc.student_id
WHERE
    grade IS NULL
    OR grade IN (0, 15)
    AND grade != 11;

----------------------------------------------------------------------------
-- 5_3
SELECT
    student_id AS id,
    name,
    family
FROM
    students
    INNER JOIN studentcourserelations ON students.id = studentcourserelations.student_id
WHERE
    course_id IN (1, 2, 3)
GROUP BY
    student_id,
    name,
    family
HAVING
    COUNT(DISTINCT course_id) = 3
    AND NOT EXISTS (
        SELECT
            1
        FROM
            studentcourserelations
        WHERE
            student_id = id
            AND course_id = 4
    );

----------------------------------------------------------------------------
-- 5_4
SELECT DISTINCT
    COUNT(student_id)
FROM
    studentcourserelations AS stc
GROUP BY
    student_id
HAVING
    (
        SELECT
            AVG(grade)
        FROM
            studentcourserelations
        WHERE
            student_id = stc.student_id
            AND grade IS NOT NULL
    ) > (
        SELECT
            AVG(grade)
        FROM
            studentcourserelations
        WHERE
            grade IS NOT NULL
    );

----------------------------------------------------------------------------
-- 5_5
SELECT
    (
        SELECT
            COUNT(DISTINCT id)
        FROM
            students
    ) AS total,
    (
        SELECT
            COUNT(DISTINCT id)
        FROM
            students
        WHERE
            isGraduated = 0
    ) AS notGraduated,
    (
        SELECT
            COUNT(DISTINCT student_id)
        FROM
            studentcourserelations
        WHERE
            grade > (
                SELECT
                    AVG(grade)
                FROM
                    studentcourserelations
                WHERE
                    grade IS NOT NULL
            )
            AND grade is not null
    ) AS top;

----------------------------------------------------------------------------
-- 5_6
DELETE FROM studentcourserelations
WHERE
    substring(student_id, 1, 3) > substring(year, 2, 4);
-- 1_1
CREATE Table StudentCourseRelations (
    id INT,
    student_id INT,
    course_id INT,
    year INT,
    grade NUMERIC(3, 1),
    PRIMARY KEY (id),
    Foreign Key (student_id) REFERENCES Students (id),
    Foreign Key (course_id) REFERENCES Courses (id)
);

INSERT INTO
    StudentCourseRelations
VALUES
    (05, 4015555, 1, 1401, 11),
    (08, 4015555, 3, NULL, 18.5),
    (11, 4025678, 3, 1403, 20),
    (04, 4025678, 3, 1402, 19),
    (02, 3779898, 1, 1380, 13),
    (01, 4001234, 1, 1401, 18),
    (07, 4015555, 2, 1400, 16),
    (09, 4004321, 1, 1401, 15),
    (10, 4001234, 3, null, 17),
    (03, 4004321, 2, 1403, null);

------------------------------------------------------------------------
-- 1_2
SELECT
    name,
    family,
    id
FROM
    students
WHERE
    name NOT IN ('محمد', 'علی')
    AND id / 10000 >= 399
    AND (
        mobile LIKE '09%'
        AND LENGTH (mobile) = 11
        OR mobile IS NULL
    )
    ------------------------------------------------------------------------
    -- 1_3
SELECT DISTINCT
    name,
    family,
    id
FROM
    students
WHERE
    name NOT IN ('محمد', 'علی')
    AND id / 10000 >= 399
    AND (
        mobile LIKE '09%'
        AND LENGTH (mobile) = 11
        OR mobile IS NULL
    )
    ------------------------------------------------------------------------
    -- 1_4
SELECT
    student_id,
    course_id,
    CASE
        WHEN course_id = 1 THEN grade -2
        WHEN course_id = 2 THEN 0
        WHEN course_id = 3 THEN grade * 1.02
    END as new_grades
FROM
    StudentCourseRelations
    ------------------------------------------------------------------------
    -- 1_5
SELECT
    stu.name,
    stu.family,
    stu.major_name,
    cou.name,
    Stc.grade
FROM
    students AS Stu,
    courses AS Cou,
    studentcourserelations AS Stc
WHERE
    Stu.id = Stc.student_id
    AND Stc.course_id = Cou.id
    AND Stc.year >= 1300
    AND Stu.isgraduated = 0
ORDER BY
    Stu.id

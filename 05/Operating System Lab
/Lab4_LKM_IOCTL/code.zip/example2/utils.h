enum {
	Command1 = _IO('A', 1),
};
struct iut_data {
	int arg1;
};
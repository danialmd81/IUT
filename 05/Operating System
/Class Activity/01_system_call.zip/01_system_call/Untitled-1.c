#include <linux/kernel.h>
#include <linux/syscalls.h>

SYSCALL_DEFINE2(add, int, a, int, b)
{
  printk(KERN_INFO "add_syscall called with %d and %d\n", a, b);
  return a + b;
}